/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package orderingsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author Zephyr
 */
public class QuantityDialog extends JDialog {
    private int quantity = -1; // Default to -1 (canceled)
    private JTextField quantityField;

    public QuantityDialog(JFrame parent, String itemName, double price, ImageIcon foodImage) {
        super(parent, "Order Quantity", true);
        setLayout(new BorderLayout(10, 10));
        setSize(370, 400);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(Color.WHITE);

        // Fonts
        Font titleFont = new Font("Arial", Font.BOLD, 18);
        Font bodyFont = new Font("Segoe UI", Font.PLAIN, 14);

        // Top Image
        JLabel imageLabel = new JLabel(foodImage);
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        add(imageLabel, BorderLayout.NORTH);

        // Center Panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // List-like display for item name and price
        JLabel nameLabel = new JLabel(itemName + " — ₱" + price);
        nameLabel.setFont(titleFont);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameLabel.setForeground(new Color(204, 0, 0)); // Jollibee red
        nameLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        centerPanel.add(nameLabel);

        // Quantity label ABOVE input
        JLabel quantityLabel = new JLabel("Enter Quantity:");
        quantityLabel.setFont(bodyFont);
        quantityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(quantityLabel);

        // Quantity text field
        quantityField = new JTextField();
        quantityField.setMaximumSize(new Dimension(200, 35));
        quantityField.setHorizontalAlignment(JTextField.CENTER);
        quantityField.setFont(new Font("Arial", Font.BOLD, 16));
        quantityField.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        centerPanel.add(Box.createVerticalStrut(5));
        centerPanel.add(quantityField);

        add(centerPanel, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);

        JButton confirmButton = new JButton("Confirm");
        confirmButton.setBackground(new Color(200,20,30)); // Jollibee yellow
        confirmButton.setForeground(Color.BLACK);
        confirmButton.setFont(bodyFont);
        confirmButton.setFocusPainted(false);
        confirmButton.setPreferredSize(new Dimension(100, 35));

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(Color.LIGHT_GRAY);
        cancelButton.setForeground(Color.BLACK);
        cancelButton.setFont(bodyFont);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(100, 35));

        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button logic
        confirmButton.addActionListener(e -> {
            try {
                int qty = Integer.parseInt(quantityField.getText().trim());
                if (qty > 0) {
                    quantity = qty;
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Enter a positive number.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid number.");
            }
        });

        cancelButton.addActionListener(e -> dispose());
    }

    public int getQuantity() {
        return quantity;
    }
}