/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package orderingsystem;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.function.Consumer;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Zephyr
 */
public class admin extends javax.swing.JFrame {
    
    Connection conn;
    Statement stmt;
    DefaultTableModel model;
    private String selectedImagePath = null;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(admin.class.getName());

    /**
     * Creates new form admin
     */
    public admin() {
        initComponents();
        setResizable(false);
        txtname.setPreferredSize(txtname.getPreferredSize());
        txtdesc.setPreferredSize(txtdesc.getPreferredSize());
        txtprice.setPreferredSize(txtprice.getPreferredSize());
        txtcategory.setPreferredSize(txtcategory.getPreferredSize());
        connectDatabase();
        setupTable();  
        listFoodItems();
        fetchPendingOrders();
        fetchSalesReport();
        updateDashboardStats();
        

    }
    
    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_orderingsystem?zeroDateTimeBehavior=convertToNull", "root", "");
            stmt = conn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed");
        }
    }
    
    private void setupTable() {
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Name", "Description", "Price", "Category", "Image", "Stock Status"});
        table.setModel(model);  // KEEP THIS!
        table.setRowHeight(60); // Make sure row is tall enough for images
        table.getColumn("Image").setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                                                                    boolean isSelected, boolean hasFocus,
                                                                    int row, int column) {
                return (value instanceof JLabel) ? (JLabel) value :
                       super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
    }
    private void listFoodItems() {
        model.setRowCount(0); // Clear old rows
        try {
            String sql = "SELECT * FROM td_fooditems";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String imagePath = rs.getString("image_path");
                ImageIcon icon = new ImageIcon(imagePath); // You might need to resize this
                Image image = icon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                JLabel imageLabel = new JLabel(new ImageIcon(image));

                model.addRow(new Object[]{
                    rs.getString("item_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category"),
                    imageLabel,
                    rs.getString("stock_status")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load food items: " + e.getMessage());
        }
    }
    private void clearFields() {
        txtname.setText("");
        txtdesc.setText("");
        txtprice.setText("");
        txtcategory.setSelectedIndex(0);
        imgPreview.setIcon(null); // Clear the image preview
        selectedImagePath = null; // Clear saved image path
    }
private void openEditPopup(int rowIndex) {
    String id = model.getValueAt(rowIndex, 0).toString();
    String name = model.getValueAt(rowIndex, 1).toString();
    String description = model.getValueAt(rowIndex, 2).toString();
    String price = model.getValueAt(rowIndex, 3).toString();
    String category = model.getValueAt(rowIndex, 4).toString();

    String stockStatus = "Available";
    if (model.getColumnCount() > 6) {
        stockStatus = model.getValueAt(rowIndex, 6).toString();
    }

    JTextField nameField = new JTextField(name);
    JTextField descriptionField = new JTextField(description);
    JTextField priceField = new JTextField(price);
    JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"Meals", "Drinks", "Dessert", "Snacks"});
    categoryComboBox.setSelectedItem(category);
    JComboBox<String> statusComboBox = new JComboBox<>(new String[]{"Available", "Out of Stock"});
    statusComboBox.setSelectedItem(stockStatus);

    // Load image path
    String imagePath = "";
    try {
        String imageQuery = "SELECT image_path FROM td_fooditems WHERE item_id = ?";
        PreparedStatement imageStmt = conn.prepareStatement(imageQuery);
        imageStmt.setString(1, id);
        ResultSet imageRs = imageStmt.executeQuery();
        if (imageRs.next()) {
            imagePath = imageRs.getString("image_path");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    JLabel imagePreview = new JLabel();
    imagePreview.setPreferredSize(new Dimension(200, 200));
    imagePreview.setHorizontalAlignment(JLabel.CENTER);
    imagePreview.setVerticalAlignment(JLabel.CENTER);
    imagePreview.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(Color.BLACK, 2),
        BorderFactory.createEmptyBorder(10, 10, 10, 10)
    ));

    if (imagePath != null && !imagePath.isEmpty()) {
        File imgFile = new File(imagePath);
        if (imgFile.exists()) {
            ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
            imagePreview.setIcon(icon);
        } else {
            imagePreview.setText("Image not found");
        }
    } else {
        imagePreview.setText("No image");
    }

    File[] selectedImage = new File[1];

    JButton browseButton = new JButton("Upload");
    browseButton.setBackground(new Color(211, 47, 47));
    browseButton.setForeground(Color.WHITE);
    browseButton.setFocusPainted(false);
    browseButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    browseButton.addActionListener(e -> {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image Files", "jpg", "png", "jpeg", "gif"));
        int resultImg = chooser.showOpenDialog(this);
        if (resultImg == JFileChooser.APPROVE_OPTION) {
            selectedImage[0] = chooser.getSelectedFile();
            ImageIcon icon = new ImageIcon(new ImageIcon(selectedImage[0].getAbsolutePath()).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
            imagePreview.setIcon(icon);
        }
    });

    // Style for fields
    Consumer<JTextField> styleField = field -> {
        field.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLACK));
        field.setBackground(Color.WHITE);
    };
    styleField.accept(nameField);
    styleField.accept(descriptionField);
    styleField.accept(priceField);
    categoryComboBox.setBackground(Color.WHITE);
    statusComboBox.setBackground(Color.WHITE);

    Font labelFont = new Font("SansSerif", Font.PLAIN, 13);

    // LEFT: Image Panel
    JPanel imagePanel = new JPanel();
    imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
    imagePanel.setBackground(Color.WHITE);
    imagePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel imageLabel = new JLabel("Image");
    imageLabel.setForeground(Color.BLACK);
    imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    imagePanel.add(imageLabel);
    imagePanel.add(Box.createVerticalStrut(5));
    imagePanel.add(imagePreview);
    imagePanel.add(Box.createVerticalStrut(10));
    imagePanel.add(browseButton);

    // RIGHT: Form Panel
    JPanel inputPanel = new JPanel();
    inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
    inputPanel.setBackground(Color.WHITE);
    inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel nameLabel = new JLabel("Name:");
    JLabel descLabel = new JLabel("Description:");
    JLabel priceLabel = new JLabel("Price:");
    JLabel categoryLabel = new JLabel("Category:");
    JLabel stockLabel = new JLabel("Stock Status:");

    for (JLabel label : new JLabel[]{nameLabel, descLabel, priceLabel, categoryLabel, stockLabel}) {
        label.setForeground(Color.BLACK);
        label.setFont(labelFont);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    for (Component comp : new Component[]{nameLabel, nameField, descLabel, descriptionField, priceLabel, priceField, categoryLabel, categoryComboBox, stockLabel, statusComboBox}) {
        inputPanel.add(comp);
        inputPanel.add(Box.createVerticalStrut(10));
    }

    // Combine panels
    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.setBackground(Color.WHITE);
    mainPanel.add(imagePanel, BorderLayout.WEST);
    mainPanel.add(inputPanel, BorderLayout.CENTER);

    // Custom button label
    UIManager.put("OptionPane.okButtonText", "Update");

    JButton updateButton = new JButton("Update");
    updateButton.setBackground(new Color(211, 47, 47));
    updateButton.setForeground(Color.WHITE);
    updateButton.setFocusPainted(false);
    updateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

    int result = JOptionPane.showConfirmDialog(this, mainPanel, "Edit Food Item", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        try {
            String newName = nameField.getText();
            String newDesc = descriptionField.getText();
            double newPrice = Double.parseDouble(priceField.getText());
            String newCategory = (String) categoryComboBox.getSelectedItem();
            String newStatus = (String) statusComboBox.getSelectedItem();

            String sql = "UPDATE td_fooditems SET name=?, description=?, price=?, category=?, stock_status=?, image_path=? WHERE item_id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, newName);
            ps.setString(2, newDesc);
            ps.setDouble(3, newPrice);
            ps.setString(4, newCategory);
            ps.setString(5, newStatus);

            if (selectedImage[0] != null) {
                ps.setString(6, selectedImage[0].getAbsolutePath());
            } else {
                ps.setString(6, imagePath);
            }

            ps.setString(7, id);
            ps.executeUpdate();

            listFoodItems();
            JOptionPane.showMessageDialog(this, "Item updated successfully!");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid price. Please enter a numeric value.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to update: " + ex.getMessage());
        }
    }
}



    
    private void searchFoodItems(String keyword) {
        model.setRowCount(0); // Clear the table

        try {
            String sql = "SELECT * FROM td_fooditems WHERE name LIKE '%" + keyword + "%' OR description LIKE '%" + keyword + "%' OR item_id LIKE '%" + keyword + "%' OR category LIKE '%" + keyword + "%'";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String imagePath = rs.getString("image_path");
                ImageIcon icon = new ImageIcon(imagePath);
                Image image = icon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                JLabel imageLabel = new JLabel(new ImageIcon(image));

                model.addRow(new Object[]{
                    rs.getString("item_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category"),
                    imageLabel,
                    rs.getString("stock_status")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search failed: " + e.getMessage());
        }
    }
    private void filterByCategory(String category) {
        model.setRowCount(0); // Clear table

        try {
            String sql = "SELECT * FROM td_fooditems WHERE category = ?";
            var ps = conn.prepareStatement(sql);
            ps.setString(1, category);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String imagePath = rs.getString("image_path");
                ImageIcon icon = new ImageIcon(imagePath);
                Image image = icon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                JLabel imageLabel = new JLabel(new ImageIcon(image));

                model.addRow(new Object[]{
                    rs.getString("item_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getString("category"),
                    imageLabel,
                    rs.getString("stock_status")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to filter: " + e.getMessage());
        }
    }
    
    private void updateDashboardStats() {
    try {
        // Meals
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM td_fooditems WHERE category = 'Meals'");
        if (rs.next()) dashMeals.setText(rs.getString(1));

        // Drinks
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_fooditems WHERE category = 'Drinks'");
        if (rs.next()) dashDrinks.setText(rs.getString(1));

        // Desserts
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_fooditems WHERE category = 'Dessert'");
        if (rs.next()) dashDesserts.setText(rs.getString(1));
        
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_fooditems WHERE category = 'Snacks'");
        if (rs.next()) dashSnacks.setText(rs.getString(1));

        // Out of stock
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_fooditems WHERE stock_status = 'Out of Stock'");
        if (rs.next()) dashStock.setText(rs.getString(1));

        // Pending Orders
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_pendingorders WHERE status = 'Pending'");
        if (rs.next()) dashPending.setText(rs.getString(1));

        // Completed Orders
        rs = stmt.executeQuery("SELECT COUNT(*) FROM td_pendingorders WHERE status = 'Paid'");
        if (rs.next()) dashTotalOrders.setText(rs.getString(1));

        // Total Earnings
        rs = stmt.executeQuery("SELECT SUM(total_amount) FROM td_pendingorders WHERE status = 'Paid'");
        if (rs.next()) {
            double earnings = rs.getDouble(1);
            dashTotalEarnings.setText("₱" + String.format("%.2f", earnings));
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating dashboard: " + e.getMessage());
    }
}
 
    private void fetchPendingOrders() {
        try {
            String query = "SELECT order_number, total_amount, status FROM td_pendingorders WHERE status = 'Pending'";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTablePending.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
                String pending = rs.getString("status");
                int orderNumber = rs.getInt("order_number");
                double amount = rs.getDouble("total_amount");
                model.addRow(new Object[]{orderNumber, "₱" + amount, pending});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading pending orders: " + e.getMessage());
        }       
    }
    private void fetchSalesReport(){
        
        try {
            String query = "SELECT order_number, total_amount, status, created_at FROM td_pendingorders WHERE status = 'Paid'";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTablesalesReport.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
            
                String pending = rs.getString("status");
                int orderNumber = rs.getInt("order_number");
                double amount = rs.getDouble("total_amount");
                String date = rs.getString("created_at");
                model.addRow(new Object[]{orderNumber, "₱" + amount, pending, date});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading pending orders: " + e.getMessage());
        }  
    }

    private void showPaymentDialog(int orderNumber, String foodDetails, double totalAmount) {
    // Create detailsArea and force it to be non-editable with a white background
    JTextArea detailsArea = new JTextArea(foodDetails);
    detailsArea.setEditable(false);
    detailsArea.setFocusable(false); // remove blinking cursor
    detailsArea.setOpaque(false); // transparent background (or use setBackground(Color.WHITE))
    detailsArea.setBorder(null); // remove border
    detailsArea.setCaretColor(new Color(0, 0, 0, 0)); // fully transparent caret
    detailsArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
    detailsArea.setLineWrap(true);
    detailsArea.setWrapStyleWord(true);

    JTextField paymentField = new JTextField();
    paymentField.setFont(new Font("SansSerif", Font.BOLD, 22));
    paymentField.setHorizontalAlignment(JTextField.RIGHT);
    paymentField.setPreferredSize(new Dimension(200, 40));

    JPanel keypadPanel = new JPanel(new GridLayout(4, 3, 10, 10));
    keypadPanel.setPreferredSize(new Dimension(300, 300));
    keypadPanel.setBackground(Color.WHITE);

    String[] keys = {"7", "8", "9", "4", "5", "6", "1", "2", "3", "0", ".", "C"};
    for (String key : keys) {
        JButton btn = new JButton(key);
        btn.setFont(new Font("SansSerif", Font.BOLD, 20));
        btn.setBackground(new Color(211, 47, 47));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> {
            if (key.equals("C")) {
                paymentField.setText("");
            } else {
                paymentField.setText(paymentField.getText() + key);
            }
        });
        keypadPanel.add(btn);
    }

    JPanel contentPanel = new JPanel();
    contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
    contentPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    contentPanel.setBackground(Color.WHITE);

    Font labelFont = new Font("SansSerif", Font.BOLD, 18);
    Font totalFont = new Font("SansSerif", Font.BOLD, 20);

    JLabel lblOrderNum = new JLabel("Order Number: " + orderNumber);
    lblOrderNum.setFont(totalFont);
    contentPanel.add(lblOrderNum);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblOrderedItems = new JLabel("Ordered Items:");
    lblOrderedItems.setFont(labelFont);
    contentPanel.add(lblOrderedItems);

    JScrollPane scroll = new JScrollPane(detailsArea);
    scroll.setPreferredSize(new Dimension(350, 100));
    contentPanel.add(scroll);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblTotal = new JLabel("Total Amount: ₱" + String.format("%.2f", totalAmount));
    lblTotal.setFont(totalFont);
    lblTotal.setForeground(new Color(211, 47, 47));
    contentPanel.add(lblTotal);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblEnterPayment = new JLabel("Enter payment amount:");
    lblEnterPayment.setFont(labelFont);
    contentPanel.add(lblEnterPayment);
    contentPanel.add(paymentField);

    contentPanel.add(Box.createVerticalStrut(10));
    contentPanel.add(keypadPanel);

    // Create custom OK and Cancel buttons
    JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
    JButton okBtn = new JButton("OK");
    JButton cancelBtn = new JButton("Cancel");

    okBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
    okBtn.setPreferredSize(new Dimension(100, 40));
    okBtn.setBackground(new Color(76, 175, 80)); // green for OK
    okBtn.setForeground(Color.WHITE);

    cancelBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
    cancelBtn.setPreferredSize(new Dimension(100, 40));
    cancelBtn.setBackground(new Color(244, 67, 54)); // red for Cancel
    cancelBtn.setForeground(Color.WHITE);

    btnPanel.add(okBtn);
    btnPanel.add(cancelBtn);
    btnPanel.setBackground(Color.WHITE);

    contentPanel.add(btnPanel);

    // Use a JDialog with a suitable parent
    JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Process Payment", true);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.add(contentPanel);
    dialog.pack();
    dialog.setLocationRelativeTo(this);

    // Button logic for OK and Cancel
    okBtn.addActionListener(e -> {
        try {
            double payment = Double.parseDouble(paymentField.getText());
            if (payment < totalAmount) {
                JOptionPane.showMessageDialog(dialog, "Payment is less than total amount. Please enter full payment.");
                return; // Do not close the dialog
            }
            String updateQuery = "UPDATE td_pendingorders SET status = 'Paid' WHERE order_number = ?";
            PreparedStatement ps = conn.prepareStatement(updateQuery);
            ps.setString(1, String.valueOf(orderNumber));
            ps.executeUpdate();

            double change = payment - totalAmount;
            JOptionPane.showMessageDialog(dialog, "Payment successful! Change: ₱" + String.format("%.2f", change));
            dialog.dispose();
            showReceipt(orderNumber, foodDetails, totalAmount, payment, change);
            fetchPendingOrders();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid payment amount. Please enter a valid number.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog, "Error updating payment: " + ex.getMessage());
        }
    });

    cancelBtn.addActionListener(e -> dialog.dispose());
    dialog.setVisible(true);
}
    
    private void showReceipt(int orderNumber, String foodDetails, double totalAmount, double payment, double change) {
        StringBuilder receipt = new StringBuilder();
        receipt.append("        Food Order Receipt\n");
        receipt.append("===================================\n");
        receipt.append("Order Number: ").append(orderNumber).append("\n");
        receipt.append("-----------------------------------\n");
        receipt.append(foodDetails);
        receipt.append("-----------------------------------\n");
        receipt.append(String.format("Total:        ₱%.2f\n", totalAmount));
        receipt.append(String.format("Payment:      ₱%.2f\n", payment));
        receipt.append(String.format("Change:       ₱%.2f\n", change));
        receipt.append("===================================\n");
        receipt.append("     Thank you for your order!\n");

        JTextArea receiptArea = new JTextArea(receipt.toString());
        receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        receiptArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(receiptArea);
        scrollPane.setPreferredSize(new Dimension(350, 300));

        // Custom dialog buttons
        Object[] options = {"Save", "Print", "Close"};
        int result = JOptionPane.showOptionDialog(this, scrollPane, "Receipt",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[2]);

        if (result == JOptionPane.YES_OPTION) {
            // Save option
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("receipt_" + orderNumber + ".txt"));
            int fileResult = fileChooser.showSaveDialog(this);
            if (fileResult == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(receipt.toString());
                    JOptionPane.showMessageDialog(this, "Receipt saved successfully.");
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(this, "Error saving receipt: " + e.getMessage());
                }
            }
        } else if (result == JOptionPane.NO_OPTION) {
            // Print option
            try {
                boolean printed = receiptArea.print();
                if (printed) {
                    JOptionPane.showMessageDialog(this, "Receipt sent to printer.");
                } else {
                    JOptionPane.showMessageDialog(this, "Print job cancelled.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error printing receipt: " + e.getMessage());
            }
        }
    }
    private String getFoodDetailsByOrderNumber(int orderNumber) {
        StringBuilder foodDetails = new StringBuilder();

        try {
            String query = "SELECT f.name, f.price, od.quantity " +
                           "FROM td_orderdetails od " +
                           "JOIN td_fooditems f ON od.item_id = f.item_id " +
                           "WHERE od.order_number = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, orderNumber);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int quantity = rs.getInt("quantity");
                double subtotal = price * quantity;

                foodDetails.append(name)
                           .append(" x")
                           .append(quantity)
                           .append(" - ₱")
                           .append(String.format("%.2f", subtotal))
                           .append("\n");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching food details: " + e.getMessage());
        }       
 
        return foodDetails.toString();
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btndashboard = new javax.swing.JButton();
        btnadd = new javax.swing.JButton();
        btnpending = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        btnviewitems = new javax.swing.JButton();
        btncompleted = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        dashMeals = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        dashDrinks = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        dashDesserts = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        dashStock = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        dashPending = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        dashTotalOrders = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        dashTotalEarnings = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        dashSnacks = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        imgPreview = new javax.swing.JLabel();
        btnupload = new javax.swing.JButton();
        txtname = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtdesc = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtprice = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtcategory = new javax.swing.JComboBox<>();
        btnadditem = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        cmbCategory = new javax.swing.JComboBox<>();
        btnRefresh = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablePending = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablesalesReport = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Panel");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 246, 229));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(221, 27, 27));
        jLabel2.setText("Hello, Admin");

        btndashboard.setBackground(new java.awt.Color(200, 20, 30));
        btndashboard.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btndashboard.setForeground(new java.awt.Color(255, 255, 255));
        btndashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-dashboard-25.png"))); // NOI18N
        btndashboard.setText(" Dashboard");
        btndashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndashboardActionPerformed(evt);
            }
        });

        btnadd.setBackground(new java.awt.Color(200, 20, 30));
        btnadd.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        btnadd.setForeground(new java.awt.Color(255, 255, 255));
        btnadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/adds.png"))); // NOI18N
        btnadd.setText("Add Menu Items");
        btnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddActionPerformed(evt);
            }
        });

        btnpending.setBackground(new java.awt.Color(200, 20, 30));
        btnpending.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnpending.setForeground(new java.awt.Color(255, 255, 255));
        btnpending.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-pending-25.png"))); // NOI18N
        btnpending.setText(" Pending Orders");
        btnpending.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpendingActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel1.setText("      © 2025 All rights reserved.");

        btnviewitems.setBackground(new java.awt.Color(200, 20, 30));
        btnviewitems.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        btnviewitems.setForeground(new java.awt.Color(255, 255, 255));
        btnviewitems.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-restaurant-menu-25.png"))); // NOI18N
        btnviewitems.setText("View Menu Items");
        btnviewitems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnviewitemsActionPerformed(evt);
            }
        });

        btncompleted.setBackground(new java.awt.Color(200, 20, 30));
        btncompleted.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btncompleted.setForeground(new java.awt.Color(255, 255, 255));
        btncompleted.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-sales-report-25.png"))); // NOI18N
        btncompleted.setText("View Sales Report");
        btncompleted.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncompletedActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(btndashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jLabel2)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btncompleted, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnadd, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(btnpending, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnviewitems, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btndashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnadd, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnviewitems, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnpending, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btncompleted, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 293, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(14, 14, 14))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 200, 640));

        jPanel3.setBackground(new java.awt.Color(221, 27, 27));

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Adobe Express - file.png"))); // NOI18N
        jLabel4.setText("Jollibee");

        jButton1.setBackground(new java.awt.Color(200, 20, 30));
        jButton1.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-logout-25.png"))); // NOI18N
        jButton1.setText("Log Out");
        jButton1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 798, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 70));

        jPanel4.setBackground(new java.awt.Color(245, 245, 245));

        jLabel3.setBackground(new java.awt.Color(221, 27, 27));
        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("   Admin Dashboard");
        jLabel3.setOpaque(true);

        jPanel6.setBackground(new java.awt.Color(255, 249, 196));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-meal-75.png"))); // NOI18N

        jLabel9.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel9.setText("Meals");

        dashMeals.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashMeals.setText("1");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(dashMeals, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(31, 31, 31))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashMeals))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel12)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(255, 249, 196));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-drink-75.png"))); // NOI18N

        jLabel19.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel19.setText("Drinks");

        dashDrinks.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashDrinks.setText("1");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(dashDrinks, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashDrinks))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 249, 196));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-dessert-75.png"))); // NOI18N

        jLabel22.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel22.setText("Desserts");

        dashDesserts.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashDesserts.setText("1");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(dashDesserts, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashDesserts))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel21)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(255, 249, 196));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-out-of-stock-75.png"))); // NOI18N

        jLabel25.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jLabel25.setText("Out of Stock");

        dashStock.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashStock.setText("1");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dashStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(54, 54, 54))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashStock))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel24)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel14.setBackground(new java.awt.Color(255, 249, 196));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-pending-75.png"))); // NOI18N

        jLabel28.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel28.setText("Pending Orders");

        dashPending.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashPending.setText("1");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dashPending, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dashPending)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel27)
                .addContainerGap())
        );

        jPanel15.setBackground(new java.awt.Color(255, 249, 196));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-order-75.png"))); // NOI18N

        jLabel31.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jLabel31.setText("Total Orders");

        dashTotalOrders.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashTotalOrders.setText("1");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                    .addComponent(dashTotalOrders, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashTotalOrders))
                    .addComponent(jLabel30))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel16.setBackground(new java.awt.Color(255, 249, 196));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-money-75.png"))); // NOI18N

        jLabel34.setFont(new java.awt.Font("Comic Sans MS", 1, 15)); // NOI18N
        jLabel34.setText("Total Earnings");

        dashTotalEarnings.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        dashTotalEarnings.setText("1");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel34)
                    .addComponent(dashTotalEarnings, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(dashTotalEarnings))
                    .addComponent(jLabel33))
                .addGap(15, 15, 15))
        );

        jPanel10.setBackground(new java.awt.Color(255, 249, 196));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-hamburger-75.png"))); // NOI18N

        jLabel11.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel11.setText("Snacks");

        dashSnacks.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        dashSnacks.setText("1");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(dashSnacks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(31, 31, 31))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashSnacks))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel17)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, 200, Short.MAX_VALUE))
                        .addGap(0, 26, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 357, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("dashboard", jPanel4);

        jPanel5.setBackground(new java.awt.Color(245, 245, 245));

        jLabel5.setBackground(new java.awt.Color(221, 27, 27));
        jLabel5.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("  Add Menu Items");
        jLabel5.setOpaque(true);

        imgPreview.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnupload.setBackground(new java.awt.Color(200, 20, 30));
        btnupload.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnupload.setForeground(new java.awt.Color(255, 255, 255));
        btnupload.setText("Upload");
        btnupload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnuploadActionPerformed(evt);
            }
        });

        txtname.setBackground(new java.awt.Color(245, 245, 245));
        txtname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtname.setMaximumSize(new java.awt.Dimension(64, 17));
        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel13.setText("Name:");

        jLabel14.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel14.setText("Description:");

        txtdesc.setBackground(new java.awt.Color(245, 245, 245));
        txtdesc.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtdesc.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtdesc.setMaximumSize(new java.awt.Dimension(65, 19));
        txtdesc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdescActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel15.setText("Price:");

        txtprice.setBackground(new java.awt.Color(245, 245, 245));
        txtprice.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtprice.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtprice.setMaximumSize(new java.awt.Dimension(64, 19));

        jLabel16.setBackground(new java.awt.Color(245, 245, 245));
        jLabel16.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel16.setText("Category:");

        txtcategory.setBackground(new java.awt.Color(245, 245, 245));
        txtcategory.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtcategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Meals", "Drinks", "Dessert", "Snacks" }));
        txtcategory.setBorder(null);
        txtcategory.setMaximumSize(new java.awt.Dimension(78, 22));

        btnadditem.setBackground(new java.awt.Color(200, 20, 30));
        btnadditem.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnadditem.setForeground(new java.awt.Color(255, 255, 255));
        btnadditem.setText("Add");
        btnadditem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnadditemActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel6.setText("Image");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnadditem, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(43, 43, 43)
                                        .addComponent(imgPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(74, 74, 74)
                                        .addComponent(btnupload, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(86, 86, 86)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtcategory, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtname, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtdesc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtprice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(imgPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnupload, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtdesc, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtprice, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtcategory, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnadditem, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(207, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("addMenu", jPanel5);

        jPanel7.setBackground(new java.awt.Color(245, 245, 245));

        jLabel7.setBackground(new java.awt.Color(221, 27, 27));
        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("  View Menu Items");
        jLabel7.setOpaque(true);
        jLabel7.setPreferredSize(new java.awt.Dimension(141, 28));

        table.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID:", "Name:", "Description:", "Price:", "Category:", "Images"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);

        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });

        btnSearch.setBackground(new java.awt.Color(200, 20, 30));
        btnSearch.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        cmbCategory.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Meals", "Drinks", "Desserts", "Snacks" }));
        cmbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoryActionPerformed(evt);
            }
        });

        btnRefresh.setBackground(new java.awt.Color(200, 20, 30));
        btnRefresh.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSearch)
                        .addGap(18, 18, 18)
                        .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRefresh)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSearch)
                        .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnRefresh))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("viewMenu", jPanel7);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setBackground(new java.awt.Color(221, 27, 27));
        jLabel8.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("  Pending Orders");
        jLabel8.setOpaque(true);
        jLabel8.setPreferredSize(new java.awt.Dimension(155, 34));

        jTablePending.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTablePending.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Order Number", "Total Amount", "Status"
            }
        ));
        jTablePending.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePendingMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTablePending);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("pending", jPanel8);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setBackground(new java.awt.Color(221, 27, 27));
        jLabel10.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("  View Sales Report");
        jLabel10.setOpaque(true);

        jTablesalesReport.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTablesalesReport.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order Number", "Total Amount", "Status", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablesalesReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablesalesReportMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablesalesReport);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("salesreport", jPanel9);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, 900, 670));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);   
    }//GEN-LAST:event_btnaddActionPerformed

    private void btndashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndashboardActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0); // Open the dashboard tab
        updateDashboardStats(); 
    }//GEN-LAST:event_btndashboardActionPerformed

    private void btnpendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpendingActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);  
    }//GEN-LAST:event_btnpendingActionPerformed

    private void btnviewitemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnviewitemsActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_btnviewitemsActionPerformed

    private void btncompletedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncompletedActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
        fetchSalesReport();
    }//GEN-LAST:event_btncompletedActionPerformed

    private void txtdescActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdescActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdescActionPerformed

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameActionPerformed

    private void btnadditemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnadditemActionPerformed
        String name = txtname.getText();
        String desc = txtdesc.getText();
        String price = txtprice.getText();
        String category = txtcategory.getSelectedItem().toString();

        if (name.isEmpty() || desc.isEmpty() || price.isEmpty() || category.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        try {
            
            double priceValue;
            try {
                priceValue = Double.parseDouble(price);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid price. Please enter a numeric value.");
                return;
            }
            
            String sql = "INSERT INTO td_fooditems (name, description, price, category, image_path) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, desc);
            ps.setDouble(3, Double.parseDouble(price));
            ps.setString(4, category);
            ps.setString(5, selectedImagePath); // Pass the saved image path
            ps.executeUpdate();

            UIManager.put("OptionPane.okButtonText", "OK");

            JOptionPane.showMessageDialog(
                this,
                "Food item added successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
            );

            clearFields();
            listFoodItems();
        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(this, "Food ID already exists.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to add food item.");
        }   
    }//GEN-LAST:event_btnadditemActionPerformed

    private void btnuploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnuploadActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select an Image");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Image files", "jpg", "jpeg", "png", "gif", "bmp"));

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            selectedImagePath = selectedFile.getAbsolutePath(); // Save the path

            // Load and scale the image to fit the preview label
            ImageIcon icon = new ImageIcon(selectedImagePath);
            Image img = icon.getImage().getScaledInstance(
                imgPreview.getWidth(), imgPreview.getHeight(), Image.SCALE_SMOOTH);
            imgPreview.setIcon(new ImageIcon(img));
        }
    }//GEN-LAST:event_btnuploadActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1 && evt.getClickCount() == 1) { // 1-click or change to 2 for double-click
            openEditPopup(selectedRow);
        }
    }//GEN-LAST:event_tableMouseClicked

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        String selectedCategory = cmbCategory.getSelectedItem().toString();
    
        if (selectedCategory.equals("All")) {
            listFoodItems(); // Show all items
        } else {
            filterByCategory(selectedCategory);
        }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        txtSearch.setText("");
        cmbCategory.setSelectedIndex(0); 
        listFoodItems();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        String keyword = txtSearch.getText().trim();
        searchFoodItems(keyword);
    }//GEN-LAST:event_btnSearchActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ads Ads = new ads();
        Ads.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void jTablePendingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePendingMouseClicked
         if (evt.getClickCount() == 1) { // One-click to open payment form
            int selectedRow = jTablePending.getSelectedRow();
            if (selectedRow != -1) {
                // Get order number
                int orderNumber = Integer.parseInt(jTablePending.getValueAt(selectedRow, 0).toString());

                // Get total amount (remove currency symbol)
                String amountStr = jTablePending.getValueAt(selectedRow, 1).toString().replace("₱", "");
                double totalAmount = Double.parseDouble(amountStr);

                // Fetch ordered food details from DB
                String foodDetails = getFoodDetailsByOrderNumber(orderNumber);

                // Show payment dialog
                showPaymentDialog(orderNumber, foodDetails, totalAmount);
            }
        }
    }//GEN-LAST:event_jTablePendingMouseClicked

    private void jTablesalesReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablesalesReportMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_jTablesalesReportMouseClicked
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new admin().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnadd;
    private javax.swing.JButton btnadditem;
    private javax.swing.JButton btncompleted;
    private javax.swing.JButton btndashboard;
    private javax.swing.JButton btnpending;
    private javax.swing.JButton btnupload;
    private javax.swing.JButton btnviewitems;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JLabel dashDesserts;
    private javax.swing.JLabel dashDrinks;
    private javax.swing.JLabel dashMeals;
    private javax.swing.JLabel dashPending;
    private javax.swing.JLabel dashSnacks;
    private javax.swing.JLabel dashStock;
    private javax.swing.JLabel dashTotalEarnings;
    private javax.swing.JLabel dashTotalOrders;
    private javax.swing.JLabel imgPreview;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTablePending;
    private javax.swing.JTable jTablesalesReport;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JComboBox<String> txtcategory;
    private javax.swing.JTextField txtdesc;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtprice;
    // End of variables declaration//GEN-END:variables
} 
