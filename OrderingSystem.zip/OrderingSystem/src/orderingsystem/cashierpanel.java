/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package orderingsystem;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Zephyr
 */
public class cashierpanel extends javax.swing.JFrame {
    
    Connection conn;
    Statement stmt;
    DefaultTableModel model;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(cashierpanel.class.getName());

    /**
     * Creates new form admin
     */
    public cashierpanel() {
        initComponents();
        setResizable(false);
        connectDatabase(); 
        fetchPendingOrders();
        

    }
    
    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_orderingsystem?zeroDateTimeBehavior=convertToNull", "root", "");
            stmt = conn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed");
        }
    }
    
 
    private void fetchPendingOrders() {
        try {
            String query = "SELECT order_number, total_amount, status FROM td_pendingorders WHERE status = 'Pending'";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTablePending.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
                String pending = rs.getString("status");
                int orderNumber = rs.getInt("order_number");
                double amount = rs.getDouble("total_amount");
                model.addRow(new Object[]{orderNumber, "₱" + amount, pending});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading pending orders: " + e.getMessage());
        }       
    }

    private void showPaymentDialog(int orderNumber, String foodDetails, double totalAmount) {
    // Create detailsArea and force it to be non-editable with a white background
    JTextArea detailsArea = new JTextArea(foodDetails);
    detailsArea.setEditable(false);
    detailsArea.setFocusable(false); // remove blinking cursor
    detailsArea.setOpaque(false); // transparent background (or use setBackground(Color.WHITE))
    detailsArea.setBorder(null); // remove border
    detailsArea.setCaretColor(new Color(0, 0, 0, 0)); // fully transparent caret
    detailsArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
    detailsArea.setLineWrap(true);
    detailsArea.setWrapStyleWord(true);

    JTextField paymentField = new JTextField();
    paymentField.setFont(new Font("SansSerif", Font.BOLD, 22));
    paymentField.setHorizontalAlignment(JTextField.RIGHT);
    paymentField.setPreferredSize(new Dimension(200, 40));

    JPanel keypadPanel = new JPanel(new GridLayout(4, 3, 10, 10));
    keypadPanel.setPreferredSize(new Dimension(300, 300));
    keypadPanel.setBackground(Color.WHITE);

    String[] keys = {"7", "8", "9", "4", "5", "6", "1", "2", "3", "0", ".", "C"};
    for (String key : keys) {
        JButton btn = new JButton(key);
        btn.setFont(new Font("SansSerif", Font.BOLD, 20));
        btn.setBackground(new Color(211, 47, 47));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> {
            if (key.equals("C")) {
                paymentField.setText("");
            } else {
                paymentField.setText(paymentField.getText() + key);
            }
        });
        keypadPanel.add(btn);
    }

    JPanel contentPanel = new JPanel();
    contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
    contentPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    contentPanel.setBackground(Color.WHITE);

    Font labelFont = new Font("SansSerif", Font.BOLD, 18);
    Font totalFont = new Font("SansSerif", Font.BOLD, 20);

    JLabel lblOrderNum = new JLabel("Order Number: " + orderNumber);
    lblOrderNum.setFont(totalFont);
    contentPanel.add(lblOrderNum);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblOrderedItems = new JLabel("Ordered Items:");
    lblOrderedItems.setFont(labelFont);
    contentPanel.add(lblOrderedItems);

    JScrollPane scroll = new JScrollPane(detailsArea);
    scroll.setPreferredSize(new Dimension(350, 100));
    contentPanel.add(scroll);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblTotal = new JLabel("Total Amount: ₱" + String.format("%.2f", totalAmount));
    lblTotal.setFont(totalFont);
    lblTotal.setForeground(new Color(211, 47, 47));
    contentPanel.add(lblTotal);

    contentPanel.add(Box.createVerticalStrut(10));

    JLabel lblEnterPayment = new JLabel("Enter payment amount:");
    lblEnterPayment.setFont(labelFont);
    contentPanel.add(lblEnterPayment);
    contentPanel.add(paymentField);

    contentPanel.add(Box.createVerticalStrut(10));
    contentPanel.add(keypadPanel);

    // Create custom OK and Cancel buttons
    JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
    JButton okBtn = new JButton("OK");
    JButton cancelBtn = new JButton("Cancel");

    okBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
    okBtn.setPreferredSize(new Dimension(100, 40));
    okBtn.setBackground(new Color(76, 175, 80)); // green for OK
    okBtn.setForeground(Color.WHITE);

    cancelBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
    cancelBtn.setPreferredSize(new Dimension(100, 40));
    cancelBtn.setBackground(new Color(244, 67, 54)); // red for Cancel
    cancelBtn.setForeground(Color.WHITE);

    btnPanel.add(okBtn);
    btnPanel.add(cancelBtn);
    btnPanel.setBackground(Color.WHITE);

    contentPanel.add(btnPanel);

    // Use a JDialog with a suitable parent
    JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Process Payment", true);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.add(contentPanel);
    dialog.pack();
    dialog.setLocationRelativeTo(this);

    // Button logic for OK and Cancel
    okBtn.addActionListener(e -> {
        try {
            double payment = Double.parseDouble(paymentField.getText());
            if (payment < totalAmount) {
                JOptionPane.showMessageDialog(dialog, "Payment is less than total amount. Please enter full payment.");
                return; // Do not close the dialog
            }
            String updateQuery = "UPDATE td_pendingorders SET status = 'Paid' WHERE order_number = ?";
            PreparedStatement ps = conn.prepareStatement(updateQuery);
            ps.setString(1, String.valueOf(orderNumber));
            ps.executeUpdate();

            double change = payment - totalAmount;
            JOptionPane.showMessageDialog(dialog, "Payment successful! Change: ₱" + String.format("%.2f", change));
            dialog.dispose();
            showReceipt(orderNumber, foodDetails, totalAmount, payment, change);
            fetchPendingOrders();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid payment amount. Please enter a valid number.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog, "Error updating payment: " + ex.getMessage());
        }
    });

    cancelBtn.addActionListener(e -> dialog.dispose());
    dialog.setVisible(true);
}


    
    private void showReceipt(int orderNumber, String foodDetails, double totalAmount, double payment, double change) {
        StringBuilder receipt = new StringBuilder();
        receipt.append("        Food Order Receipt\n");
        receipt.append("===================================\n");
        receipt.append("Order Number: ").append(orderNumber).append("\n");
        receipt.append("-----------------------------------\n");
        receipt.append(foodDetails);
        receipt.append("-----------------------------------\n");
        receipt.append(String.format("Total:        ₱%.2f\n", totalAmount));
        receipt.append(String.format("Payment:      ₱%.2f\n", payment));
        receipt.append(String.format("Change:       ₱%.2f\n", change));
        receipt.append("===================================\n");
        receipt.append("     Thank you for your order!\n");

        JTextArea receiptArea = new JTextArea(receipt.toString());
        receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        receiptArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(receiptArea);
        scrollPane.setPreferredSize(new Dimension(350, 300));

        // Custom dialog buttons
        Object[] options = {"Save", "Print", "Close"};
        int result = JOptionPane.showOptionDialog(this, scrollPane, "Receipt",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[2]);

        if (result == JOptionPane.YES_OPTION) {
            // Save option
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("receipt_" + orderNumber + ".txt"));
            int fileResult = fileChooser.showSaveDialog(this);
            if (fileResult == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(receipt.toString());
                    JOptionPane.showMessageDialog(this, "Receipt saved successfully.");
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(this, "Error saving receipt: " + e.getMessage());
                }
            }
        } else if (result == JOptionPane.NO_OPTION) {
            // Print option
            try {
                boolean printed = receiptArea.print();
                if (printed) {
                    JOptionPane.showMessageDialog(this, "Receipt sent to printer.");
                } else {
                    JOptionPane.showMessageDialog(this, "Print job cancelled.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error printing receipt: " + e.getMessage());
            }
        }
    }
    private String getFoodDetailsByOrderNumber(int orderNumber) {
        StringBuilder foodDetails = new StringBuilder();

        try {
            String query = "SELECT f.name, f.price, od.quantity " +
                           "FROM td_orderdetails od " +
                           "JOIN td_fooditems f ON od.item_id = f.item_id " +
                           "WHERE od.order_number = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, orderNumber);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int quantity = rs.getInt("quantity");
                double subtotal = price * quantity;

                foodDetails.append(name)
                           .append(" x")
                           .append(quantity)
                           .append(" - ₱")
                           .append(String.format("%.2f", subtotal))
                           .append("\n");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching food details: " + e.getMessage());
        }       
 
        return foodDetails.toString();
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablePending = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Panel");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 246, 229));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(221, 27, 27));
        jLabel2.setText("Hello, Cashier");

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel1.setText("      © 2025 All rights reserved.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 576, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 200, 640));

        jPanel3.setBackground(new java.awt.Color(221, 27, 27));

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Adobe Express - file.png"))); // NOI18N
        jLabel4.setText("Jollibee");

        jButton1.setBackground(new java.awt.Color(200, 20, 30));
        jButton1.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-logout-25.png"))); // NOI18N
        jButton1.setText("Log Out");
        jButton1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 798, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 70));

        jPanel10.setBackground(new java.awt.Color(245, 245, 245));

        jLabel8.setBackground(new java.awt.Color(221, 27, 27));
        jLabel8.setFont(new java.awt.Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-pending-25.png"))); // NOI18N
        jLabel8.setText(" Pending Orders");
        jLabel8.setOpaque(true);
        jLabel8.setPreferredSize(new java.awt.Dimension(155, 34));

        jTablePending.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTablePending.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Order Number", "Total Amount", "Status"
            }
        ));
        jTablePending.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePendingMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTablePending);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 900, 640));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 706, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ads Ads = new ads();
        Ads.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTablePendingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePendingMouseClicked
        if (evt.getClickCount() == 1) { // One-click to open payment form
            int selectedRow = jTablePending.getSelectedRow();
            if (selectedRow != -1) {
                // Get order number
                int orderNumber = Integer.parseInt(jTablePending.getValueAt(selectedRow, 0).toString());

                // Get total amount (remove currency symbol)
                String amountStr = jTablePending.getValueAt(selectedRow, 1).toString().replace("₱", "");
                double totalAmount = Double.parseDouble(amountStr);

                // Fetch ordered food details from DB
                String foodDetails = getFoodDetailsByOrderNumber(orderNumber);

                // Show payment dialog
                showPaymentDialog(orderNumber, foodDetails, totalAmount);
            }
        }
    }//GEN-LAST:event_jTablePendingMouseClicked
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new cashierpanel().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTablePending;
    // End of variables declaration//GEN-END:variables
} 
