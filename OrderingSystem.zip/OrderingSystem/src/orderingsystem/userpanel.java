/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package orderingsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.Timer;
/**
 *
 * @author Zephyr
 */
public class userpanel extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(userpanel.class.getName());
    
       Connection conn;
       Statement stmt;
       private double totalAmount = 0.0;
       int labelClickCount = 0;
       private Timer inactivityTimer;
        private static boolean adsOpened = false;

    /**
     * Creates new form userpanel
     */
    public userpanel() {
        initComponents();
        connectDatabase();
        setResizable(false);
        setupInactivityTimer();
        addActivityListeners();
        inactivityTimer.start();

        // Initialize orderListPanel BEFORE using it
        orderListPanel = new JPanel();
        orderListPanel.setLayout(new BoxLayout(orderListPanel, BoxLayout.Y_AXIS));
        orderScrollPane.setViewportView(orderListPanel);
        

        
        listFoodItemsForCustomerDashboard("All"); // Also update if using category filtering    
    }
    
    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_orderingsystem?zeroDateTimeBehavior=convertToNull", "root", "");
            stmt = conn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }
    }
    private void setupInactivityTimer() {
    inactivityTimer = new Timer(10000, e -> { // 10 seconds of no activity
        inactivityTimer.stop();

        if (!adsOpened) {
            adsOpened = true;

            // Close userpanel
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) {
                window.dispose();
            }

            // Open ads
            ads adFrame = new ads();
            this.dispose();
            adFrame.setVisible(true);

            // Reset flag when ads window is closed
            adFrame.addWindowListener(new WindowAdapter() {
                public void windowClosed(WindowEvent e) {
                    adsOpened = false;
                }
            });
        }
    });
    inactivityTimer.setRepeats(false);
}
    private void addActivityListeners() {
    AWTEventListener listener = new AWTEventListener() {
        public void eventDispatched(AWTEvent event) {
            if (event instanceof MouseEvent || event instanceof KeyEvent) {
                if (inactivityTimer != null) {
                    inactivityTimer.restart();
                }
            }
        }
    };
    Toolkit.getDefaultToolkit().addAWTEventListener(listener,
            AWTEvent.MOUSE_EVENT_MASK | AWTEvent.KEY_EVENT_MASK);
}

    private void listFoodItemsForCustomerDashboard(String categoryFilter) {
        ItemsPanel.removeAll();
        ItemsPanel.setLayout(new java.awt.GridLayout(0, 3, 10, 10));
        ItemsPanel.setPreferredSize(null);

        try {
            String sql;
            if (categoryFilter.equals("All")) {
                sql = "SELECT * FROM td_fooditems";
            } else {
                sql = "SELECT * FROM td_fooditems WHERE category = ?";
            }

            PreparedStatement ps = conn.prepareStatement(sql);

            if (!categoryFilter.equals("All")) {
                ps.setString(1, categoryFilter);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                String imagePath = rs.getString("image_path");
                String status = rs.getString("stock_status");

                FoodItemPanel item = new FoodItemPanel();
                item.setNameText(name);
                item.setPriceText("₱" + price);

                ImageIcon scaledIcon = null;
                try {
                    ImageIcon icon = new ImageIcon(imagePath);
                    Image img = icon.getImage();
                    int width = item.getImageLabel().getWidth();
                    int height = item.getImageLabel().getHeight();
                    if (width <= 0 || height <= 0) {
                        width = 170;
                        height = 122;
                    }
                    Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                    scaledIcon = new ImageIcon(scaledImg);
                    item.setImageIcon(scaledIcon);
                } catch (Exception ex) {
                    item.setImageIcon(null);
                }

                final ImageIcon finalScaledIcon = scaledIcon;
                item.setStockStatusText(status);
                item.getImageLabel().addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (!"Available".equalsIgnoreCase(status)) {
                            JOptionPane.showMessageDialog(null, "Sorry, this food is out of stock.");
                        } else {
                            openQuantityDialog(name, price, finalScaledIcon);
                        }
                    }
                });

                item.setPreferredSize(new Dimension(150, 230));
                JPanel wrapper = new JPanel(new BorderLayout());
                wrapper.setBorder(null);
                wrapper.setOpaque(false);
                wrapper.add(item, BorderLayout.CENTER);

                ItemsPanel.add(item);
            }

            ItemsPanel.revalidate();
            ItemsPanel.repaint();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load food items: " + e.getMessage());
        }
    }
     private void openQuantityDialog(String itemName, double price, ImageIcon imageIcon) {
        QuantityDialog dialog = new QuantityDialog(this, itemName, price, imageIcon);
        dialog.setVisible(true);

        int qty = dialog.getQuantity();
        if (qty > 0) {
            // Check ni ari if ang item nag exist ba siya sa order list
            boolean itemFound = false;

            for (Component comp : orderListPanel.getComponents()) {
                if (comp instanceof JPanel wrapperPanel) {
                    for (Component inner : ((JPanel) wrapperPanel).getComponents()) {
                        if (inner instanceof OrderItemPanel itemPanel) {
                            if (itemPanel.getNameText().equals(itemName)) {
                                // Item exists, update sa quantity
                                int oldQty = itemPanel.getQuantity();
                                int newQty = oldQty + qty;
                                itemPanel.setQuantityText(newQty);

                                // Update sad ang total amount
                                double oldTotal = oldQty * price;
                                double newTotal = newQty * price;
                                totalAmount = totalAmount - oldTotal + newTotal;

                                lblTotal.setText("₱" + String.format("%.2f", totalAmount));

                                itemFound = true;
                                break;
                            }
                        }
                    }
                }
                if (itemFound) break;
            }

            if (!itemFound) {
                // if ang item wala nag exist, create siya ug bago nga OrderItemPanel
                double itemTotal = qty * price;
                totalAmount += itemTotal;

                OrderItemPanel itemPanel = new OrderItemPanel();
                itemPanel.setNameText(itemName);
                itemPanel.setQuantityText(qty);
                itemPanel.setPriceText(price);

                JPanel wrapper = new JPanel(new BorderLayout());
                wrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                wrapper.setOpaque(false);
                wrapper.add(itemPanel, BorderLayout.CENTER);

                itemPanel.setWrapperPanel(wrapper);
                itemPanel.setOrderListPanel(orderListPanel);
                itemPanel.setTotalLabel(lblTotal);
                itemPanel.setTotalAmountHandler(amount -> {
                    totalAmount -= amount;
                    lblTotal.setText("₱" + String.format("%.2f", totalAmount));
                });

                orderListPanel.add(wrapper);
                orderListPanel.add(Box.createVerticalStrut(5));
                orderListPanel.revalidate();
                orderListPanel.repaint();

                lblTotal.setText("₱" + String.format("%.2f", totalAmount));
            }

            JOptionPane.showMessageDialog(this, "You ordered " + qty + " of " + itemName);
        }
    }
    private void placeOrder() {
        if (orderListPanel.getComponentCount() == 0) {
            JOptionPane.showMessageDialog(this, "No items in order.");
            return;
        }

        try {
            // Get new order number
            String query = "SELECT MAX(CAST(order_number AS UNSIGNED)) FROM td_pendingorders";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            int newOrderNumber = 1;

            if (rs.next()) {
                int lastNumber = rs.getInt(1);
                if (lastNumber >= 150) {
                    JOptionPane.showMessageDialog(this, "Order limit reached (150).");
                    return;
                }
                newOrderNumber = lastNumber + 1;
            }

            // Insert into td_pendingorders
            String insertOrder = "INSERT INTO td_pendingorders (order_number, total_amount, status) VALUES (?, ?, ?)";
            PreparedStatement psOrder = conn.prepareStatement(insertOrder);
            psOrder.setString(1, String.valueOf(newOrderNumber));
            psOrder.setDouble(2, totalAmount);
            psOrder.setString(3, "Pending");
            psOrder.executeUpdate();

            // Insert each order item into td_orderdetails
            for (Component comp : orderListPanel.getComponents()) {
                if (comp instanceof JPanel wrapperPanel) {
                    for (Component inner : wrapperPanel.getComponents()) {
                        if (inner instanceof OrderItemPanel itemPanel) {
                            String itemName = itemPanel.getNameText();
                            double price = itemPanel.getPrice();
                            int quantity = itemPanel.getQuantity();

                            // Lookup item_id
                            int itemId = -1;
                            String itemQuery = "SELECT item_id FROM td_fooditems WHERE name = ?";
                            PreparedStatement psItem = conn.prepareStatement(itemQuery);
                            psItem.setString(1, itemName);
                            ResultSet rsItem = psItem.executeQuery();
                            if (rsItem.next()) {
                                itemId = rsItem.getInt("item_id");
                            }

                            if (itemId != -1) {
                                String insertDetail = "INSERT INTO td_orderdetails (order_number, item_id, quantity, price) VALUES (?, ?, ?, ?)";
                                PreparedStatement psDetail = conn.prepareStatement(insertDetail);
                                psDetail.setString(1, String.valueOf(newOrderNumber));
                                psDetail.setInt(2, itemId);
                                psDetail.setInt(3, quantity);
                                psDetail.setDouble(4, price);
                                psDetail.executeUpdate();
                            }
                        }
                    }
                }
            }
            
            JPanel summaryPanel = new JPanel();
            summaryPanel.setLayout(new BorderLayout(10, 10));
            summaryPanel.setPreferredSize(new Dimension(400, 300));
            summaryPanel.setBackground(Color.WHITE);

            JLabel headerLabel = new JLabel("Thank you for ordering at Jollibee!");
            headerLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            headerLabel.setForeground(new Color(183, 28, 28));  // Dark Red
            summaryPanel.add(headerLabel);
            summaryPanel.add(Box.createVerticalStrut(10));

            // Order number (top)
            JLabel orderNumLabel = new JLabel("Order Number: " + newOrderNumber);
            orderNumLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
            orderNumLabel.setForeground(new Color(211, 47, 47));
            orderNumLabel.setHorizontalAlignment(SwingConstants.CENTER);
            summaryPanel.add(orderNumLabel, BorderLayout.NORTH);

            // Items (center)
            JTextArea itemsArea = new JTextArea();
            itemsArea.setEditable(false);
            itemsArea.setBackground(Color.WHITE);
            itemsArea.setForeground(Color.BLACK);
            itemsArea.setFont(new Font("SansSerif", Font.PLAIN, 14));

            double computedTotal = 0.0;
            StringBuilder itemList = new StringBuilder();

            for (Component comp : orderListPanel.getComponents()) {
                if (comp instanceof JPanel wrapperPanel) {
                    for (Component inner : wrapperPanel.getComponents()) {
                        if (inner instanceof OrderItemPanel itemPanel) {
                            String itemName = itemPanel.getNameText();
                            double price = itemPanel.getPrice();
                            int quantity = itemPanel.getQuantity();
                            double subtotal = price * quantity;
                            computedTotal += subtotal;

                            itemList.append(itemName)
                                    .append(" x").append(quantity)
                                    .append(" - ₱").append(String.format("%.2f", subtotal))
                                    .append("\n");
                        }
                    }
                }
            }
            itemsArea.setText(itemList.toString());
            summaryPanel.add(new JScrollPane(itemsArea), BorderLayout.CENTER);

            // Total (bottom)
            JLabel totalLabel = new JLabel("Total: ₱" + String.format("%.2f", computedTotal));
            totalLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            totalLabel.setForeground(new Color(211, 47, 47));
            totalLabel.setHorizontalAlignment(SwingConstants.CENTER);
            summaryPanel.add(totalLabel, BorderLayout.SOUTH);

            // Show summary
            JOptionPane.showMessageDialog(this, summaryPanel, "Order Summary", JOptionPane.PLAIN_MESSAGE);


            // Clear the cart
            orderListPanel.removeAll();
            orderListPanel.revalidate();
            orderListPanel.repaint();
            totalAmount = 0.0;
            lblTotal.setText("₱0.00");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to place order: " + e.getMessage());
        }
    }




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btnAll = new javax.swing.JButton();
        btnMeals = new javax.swing.JButton();
        btnDrinks = new javax.swing.JButton();
        btnDessert = new javax.swing.JButton();
        btnSnacks = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ItemsPanel = new javax.swing.JPanel();
        orderScrollPane = new javax.swing.JScrollPane();
        orderListPanel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        btnOrder = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Jollibee");
        setResizable(false);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(221, 27, 27));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Adobe Express - file.png"))); // NOI18N
        jLabel1.setText("Jollibee");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(930, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 80));

        jPanel1.setBackground(new java.awt.Color(255, 246, 229));

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(200, 20, 30));
        jLabel2.setText("    Menu");

        btnAll.setBackground(new java.awt.Color(200, 20, 30));
        btnAll.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnAll.setForeground(new java.awt.Color(255, 255, 255));
        btnAll.setText("All");
        btnAll.setFocusable(false);
        btnAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAllActionPerformed(evt);
            }
        });

        btnMeals.setBackground(new java.awt.Color(200, 20, 30));
        btnMeals.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnMeals.setForeground(new java.awt.Color(255, 255, 255));
        btnMeals.setText("Meals");
        btnMeals.setFocusable(false);
        btnMeals.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMealsActionPerformed(evt);
            }
        });

        btnDrinks.setBackground(new java.awt.Color(200, 20, 30));
        btnDrinks.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnDrinks.setForeground(new java.awt.Color(255, 255, 255));
        btnDrinks.setText("Drinks");
        btnDrinks.setFocusable(false);
        btnDrinks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDrinksActionPerformed(evt);
            }
        });

        btnDessert.setBackground(new java.awt.Color(200, 20, 30));
        btnDessert.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnDessert.setForeground(new java.awt.Color(255, 255, 255));
        btnDessert.setText("Desserts");
        btnDessert.setFocusable(false);
        btnDessert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDessertActionPerformed(evt);
            }
        });

        btnSnacks.setBackground(new java.awt.Color(200, 20, 30));
        btnSnacks.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnSnacks.setForeground(new java.awt.Color(255, 255, 255));
        btnSnacks.setText("Snacks");
        btnSnacks.setFocusable(false);
        btnSnacks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSnacksActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMeals, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAll, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                    .addComponent(btnDrinks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDessert, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSnacks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAll, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnMeals, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDrinks, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDessert, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSnacks, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(269, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 130, 610));

        jPanel9.setBackground(new java.awt.Color(221, 27, 27));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 620, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 80, 10, 620));

        jLabel4.setBackground(new java.awt.Color(200, 20, 30));
        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("                            Current Order");
        jLabel4.setOpaque(true);
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 90, 320, 30));

        jPanel2.setBackground(new java.awt.Color(221, 27, 27));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 690, 1100, 10));

        ItemsPanel.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout ItemsPanelLayout = new javax.swing.GroupLayout(ItemsPanel);
        ItemsPanel.setLayout(ItemsPanelLayout);
        ItemsPanelLayout.setHorizontalGroup(
            ItemsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 628, Short.MAX_VALUE)
        );
        ItemsPanelLayout.setVerticalGroup(
            ItemsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 608, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(ItemsPanel);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 620, 610));

        orderScrollPane.setBackground(new java.awt.Color(255, 246, 229));

        orderListPanel.setEnabled(false);
        orderListPanel.setLayout(new java.awt.GridLayout(1, 1));
        orderScrollPane.setViewportView(orderListPanel);

        jPanel4.add(orderScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 170, 310, 430));

        jPanel6.setBackground(new java.awt.Color(245, 245, 245));

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel3.setText("TOTAL:");

        lblTotal.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTotal.setText("₱ 0.0");

        btnOrder.setBackground(new java.awt.Color(200, 20, 30));
        btnOrder.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        btnOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnOrder.setText("Review + Pay for Orders");
        btnOrder.setFocusable(false);
        btnOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnOrder, javax.swing.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lblTotal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnOrder)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 610, 300, 70));

        jButton1.setBackground(new java.awt.Color(200, 20, 30));
        jButton1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Clear All");
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 130, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderActionPerformed
        placeOrder();
    }//GEN-LAST:event_btnOrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        orderListPanel.removeAll();   // Remove all order items
        orderListPanel.revalidate();  // Refresh layout
        orderListPanel.repaint();     // Repaint to update UI

        totalAmount = 0.0;            // ✅ Reset total
        lblTotal.setText("₱0.00");    // ✅ Reset label
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAllActionPerformed
        listFoodItemsForCustomerDashboard("All");
    }//GEN-LAST:event_btnAllActionPerformed

    private void btnMealsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMealsActionPerformed
        listFoodItemsForCustomerDashboard("Meals");
    }//GEN-LAST:event_btnMealsActionPerformed

    private void btnDrinksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDrinksActionPerformed
        listFoodItemsForCustomerDashboard("Drinks");
    }//GEN-LAST:event_btnDrinksActionPerformed

    private void btnDessertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDessertActionPerformed
        listFoodItemsForCustomerDashboard("Dessert");
    }//GEN-LAST:event_btnDessertActionPerformed

    private void btnSnacksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSnacksActionPerformed
        // TODO add your handling code here:
        listFoodItemsForCustomerDashboard("Snacks");
    }//GEN-LAST:event_btnSnacksActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        labelClickCount++; 

        if (labelClickCount == 3) {
            Login login = new Login();
            login.setVisible(true);   
            this.dispose();            
            labelClickCount = 0;     
        }
    }//GEN-LAST:event_jLabel1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
  

    java.awt.EventQueue.invokeLater(() -> {
        new userpanel().setVisible(true); // Replace MyForm with your JFrame class
    });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ItemsPanel;
    private javax.swing.JButton btnAll;
    private javax.swing.JButton btnDessert;
    private javax.swing.JButton btnDrinks;
    private javax.swing.JButton btnMeals;
    private javax.swing.JButton btnOrder;
    private javax.swing.JButton btnSnacks;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel orderListPanel;
    private javax.swing.JScrollPane orderScrollPane;
    // End of variables declaration//GEN-END:variables
}
